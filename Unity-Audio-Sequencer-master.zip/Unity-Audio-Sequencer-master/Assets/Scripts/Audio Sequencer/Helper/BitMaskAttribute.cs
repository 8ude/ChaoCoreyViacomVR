﻿using UnityEngine;

public class BitMaskAttribute : PropertyAttribute
{
    #region Other Members

    #endregion
}